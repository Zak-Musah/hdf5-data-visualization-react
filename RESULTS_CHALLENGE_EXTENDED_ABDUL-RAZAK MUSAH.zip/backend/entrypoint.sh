#!/bin/bash
echo "Starting api backend ..."

python manage.py run -h 0.0.0.0